
package PasajeroDAO;

import PasajeroDAO.Pasajero;
import java.util.ArrayList;
import java.util.List;

import PasajeroDAO.Pasajero;



public interface  DAOpasajero  {  

 public List<Pasajero> consultarTodos();   
    
 void consultarUno (String nombre);
 
 void insertar (Pasajero p);
 
 void actualizar (String nombreAnterior, String nombreNuevo);
 
 void eliminar (String apellido); 

    
 ArrayList<Pasajero> cargarLista();
 
}
