

package PasajeroDAO;

import java.util.Date;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import viajes.Conexion;
import PasajeroDAO.Pasajero;
 


public final class Pasajero {
    
    // atributos
    private int idPasajero;
    private String nombre;
    private String apellido;
    private Date fechaNacimiento;
    private String pasaporte;
    private int telefono;
    private String mail;
    private String genero;

    //constructores
    public Pasajero() {
    }

    public Pasajero(int idPasajero, String nombre, String apellido, Date fecha, String pasaporte, int telefono, String mail, String genero) {
        this.setIdPasajero(idPasajero);
        this.setNombre(nombre);
        this.setApellido(apellido);
        this.setFechaNacimiento(fechaNacimiento);
        this.setPasaporte(pasaporte);
        this.setTelefono(telefono);
        this.setMail(mail);
        this.setGenero(genero);
        
    }
    
    
    
    

    // getters and setters
    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    
    public int getTelefono() {
        return telefono;
    }

    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }

    public String getPasaporte() {
        return pasaporte;
    }

    public void setPasaporte(String pasaporte) {
        this.pasaporte = pasaporte;
    }



    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public Date getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(Date fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }
  
    
    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    

    public int getIdPasajero() {
        return idPasajero;
    }

    public void setIdPasajero(int idPasajero) {
        this.idPasajero = idPasajero;
    }

    
    // metodos

    @Override
    public String toString() {
        return idPasajero + " - " + nombre + " - " + apellido + " - " + fechaNacimiento + " - " + pasaporte + " - " + telefono + " - " + mail + " - " + genero;
    }
    
    // metodos de acceso a datos ABMC (CRUD)
 //
    

}
