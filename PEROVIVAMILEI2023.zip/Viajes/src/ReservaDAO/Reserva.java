

package ReservaDAO;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import viajes.Conexion;
import PasajeroDAO.Pasajero;
import VueloDAO.Vuelo;
import java.sql.Time;

public class Reserva {

    public enum EstadoReserva {
        Confirmado,
        Pendiente,
        Cancelado
    }

    private int idReserva;
    private Pasajero pasajero;
    private Vuelo vuelo;
    private Date fechaReserva;
    private Time horaSalidaVuelo;     // se importa la hora de salida de la clase vuelo 
    private EstadoReserva estadoReserva;
    private int cantidadAsientos;

    public Reserva() {
        
    }

    @Override
    public String toString() {
        return "Reserva{" + "idReserva=" + idReserva + ", pasajero=" + pasajero + ", vuelo=" + vuelo + ", fechaReserva=" + fechaReserva + ", horaSalidaVuelo=" + horaSalidaVuelo + ", estadoReserva=" + estadoReserva + ", cantidadAsientos=" + cantidadAsientos + '}';
    }

    public Reserva(int idReserva, Pasajero pasajero, Vuelo vuelo, Date fechaReserva,Time horaSalidaVuelo, EstadoReserva estadoReserva, int cantidadAsientos) {
        this.setIdReserva(idReserva);
        this.setPasajero(pasajero);
        this.setVuelo(vuelo);
        this.setFechaReserva(fechaReserva);
        this.setHoraSalidaVuelo(horaSalidaVuelo);
        this.setEstadoReserva(estadoReserva);
        this.setCantidadAsientos(cantidadAsientos);
    }

    // Métodos de acceso a datos ABMC (CRUD)

/*   public static void insertar(Reserva reserva) throws ClassNotFoundException, SQLException, InstantiationException, IllegalAccessException {
        Connection unaConexion = Conexion.obtenerConexion();
        String unaInsercion = "INSERT INTO reservas (id_pasajero, id_vuelo, fechaReserva, estadoReserva, cantidadAsientos) VALUES (?, ?, ?, ?, ?)";
        PreparedStatement unaSentencia = unaConexion.prepareStatement(unaInsercion);
        unaSentencia.setInt(1, reserva.getPasajero().getIdPasajero());
        unaSentencia.setInt(2, reserva.getVuelo().getIdVuelo());
        unaSentencia.setDate(3, (java.sql.Date) reserva.getFechaReserva());
        unaSentencia.setString(4, reserva.getEstadoReserva().toString());
        unaSentencia.setInt(5, reserva.getCantidadAsientos());
        unaSentencia.execute();
        System.out.println("Inserción de reserva correcta");
        unaConexion.close();
    }

    public static List<Reserva> obtenerTodas() throws ClassNotFoundException, SQLException, InstantiationException, IllegalAccessException {
    List<Reserva> reservas = new ArrayList<>();
    Connection unaConexion = Conexion.obtenerConexion();
    String unaConsulta = "SELECT * FROM reservas";
    PreparedStatement unaSentencia = unaConexion.prepareStatement(unaConsulta);
    ResultSet unResultado = unaSentencia.executeQuery();

    while (unResultado.next()) {
        Reserva reserva = new Reserva();
        reserva.setIdReserva(unResultado.getInt("id_reserva"));
        reserva.setPasajero(obtenerPasajeroPorId(unResultado.getInt("id_pasajero")));
        reserva.setVuelo(obtenerVueloPorId(unResultado.getInt("id_vuelo")));
        
        // Utiliza el método getTimestamp para obtener la fecha y hora
        reserva.setFechaReserva(new Date(unResultado.getTimestamp("fechaReserva").getTime()));
        
        reserva.setEstadoReserva(EstadoReserva.valueOf(unResultado.getString("estadoReserva")));
        reserva.setCantidadAsientos(unResultado.getInt("cantidadAsientos"));

        reservas.add(reserva);
    }

    unaConexion.close();
    return reservas;
}


    private static Pasajero obtenerPasajeroPorId(int idPasajero) throws ClassNotFoundException, SQLException, InstantiationException, IllegalAccessException {
        Connection unaConexion = Conexion.obtenerConexion();
        String unaConsulta = "SELECT * FROM pasajeros WHERE id_pasajero = ?";
        PreparedStatement unaSentencia = unaConexion.prepareStatement(unaConsulta);
        unaSentencia.setInt(1, idPasajero);
        ResultSet unResultado = unaSentencia.executeQuery();

        Pasajero pasajero = null;

        if (unResultado.next()) {
            pasajero = new Pasajero();
            pasajero.setIdPasajero(unResultado.getInt("id_pasajero"));
            pasajero.setNombre(unResultado.getString("nombre"));
            pasajero.setApellido(unResultado.getString("apellido"));
            pasajero.setFechaNacimiento(unResultado.getDate("fechaNacimiento"));
            pasajero.setPasaporte(unResultado.getString("pasaporte"));
            pasajero.setTelefono(unResultado.getInt("telefono"));
            pasajero.setMail(unResultado.getString("mail"));
            pasajero.setGenero(unResultado.getString("genero"));
        }

        unaConexion.close();
        return pasajero;
    }

    private static Vuelo obtenerVueloPorId(int idVuelo) throws ClassNotFoundException, SQLException, InstantiationException, IllegalAccessException {
        Connection unaConexion = Conexion.obtenerConexion();
        String unaConsulta = "SELECT * FROM vuelos WHERE id_vuelo = ?";
        PreparedStatement unaSentencia = unaConexion.prepareStatement(unaConsulta);
        unaSentencia.setInt(1, idVuelo);
        ResultSet unResultado = unaSentencia.executeQuery();

        Vuelo vuelo = null;

        if (unResultado.next()) {
            vuelo = new Vuelo();
            vuelo.setIdVuelo(unResultado.getInt("id_vuelo"));
            vuelo.setVuelo(unResultado.getString("vuelo"));
            vuelo.setOrigen(unResultado.getString("origen"));
            vuelo.setDestino(unResultado.getString("destino"));
            vuelo.setFechaSalida(unResultado.getDate("fechaSalida"));
            vuelo.setHoraSalida(unResultado.getTime("horaSalida"));
            vuelo.setAsientos(unResultado.getInt("asientos"));
        }

        unaConexion.close();
        return vuelo;
    }
*/
    public int getIdReserva() {
        return idReserva;
    }

    public void setIdReserva(int idReserva) {
        this.idReserva = idReserva;
    }

    public Pasajero getPasajero() {
        return pasajero;
    }

    public void setPasajero(Pasajero pasajero) {
        this.pasajero = pasajero;
    }

    public Vuelo getVuelo() {
        return vuelo;
    }

    public void setVuelo(Vuelo vuelo) {
        this.vuelo = vuelo;
    }

    public Date getFechaReserva() {
        return fechaReserva;
    }

    public void setFechaReserva(Date fechaReserva) {
        this.fechaReserva = fechaReserva;
    }
    
    
   

    public EstadoReserva getEstadoReserva() {
        return estadoReserva;
    }

    public void setEstadoReserva(EstadoReserva estadoReserva) {
        this.estadoReserva = estadoReserva;
    }

    public int getCantidadAsientos() {
        return cantidadAsientos;
    }

    public void setCantidadAsientos(int cantidadAsientos) {
        this.cantidadAsientos = cantidadAsientos;
    }
     
    public Time getHoraSalidaVuelo() {
        return horaSalidaVuelo;
    }

    public void setHoraSalidaVuelo(Time horaSalidaVuelo) {
        this.horaSalidaVuelo = horaSalidaVuelo;
    }
}
    
    


