
package VueloDAO;

import PasajeroDAO.Pasajero;
import VueloDAO.Vuelo;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public interface DAOvuelo {
    
public List<Vuelo> consultarTodos();
 
 void insertar(Vuelo v);
 
 void actualizar(String vueloAnterior, String vueloNuevo); //// 
 
void eliminar(int idVuelo); /////// 
 
 ArrayList<Vuelo> cargarLista();


}
