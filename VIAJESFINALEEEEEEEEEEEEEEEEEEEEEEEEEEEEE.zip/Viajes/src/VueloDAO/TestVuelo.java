
package VueloDAO;
import viajes.Conexion;

public class TestVuelo {

    
    public static void main(String[] args) {
        
        VueloDAOIMPLS v = new VueloDAOIMPLS(){};
        
        v.cargarLista();
    }
    
}
