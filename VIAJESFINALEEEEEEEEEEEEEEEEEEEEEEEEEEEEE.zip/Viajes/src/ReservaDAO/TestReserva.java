
package ReservaDAO;

import viajes.Conexion;
import ReservaDAO.ReservaDAOIMPLS;
import PasajeroDAO.PasajeroDAOIMPLS;

public class TestReserva {

    
    public static void main(String[] args) {
        // TODO code application logic here
        
        ReservaDAOIMPLS r = new ReservaDAOIMPLS();
        
        r.consultarTodos();
    }
    
}
