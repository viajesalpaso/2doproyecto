
package ReservaDAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import viajes.Conexion;
import ReservaDAO.Reserva;
import PasajeroDAO.Pasajero;
import VueloDAO.Vuelo;
import VueloDAO.VueloDAOIMPLS;


public class ReservaDAOIMPLS implements DAOreserva{

    @Override
    public void insertar(Reserva reserva) {
    Connection unaConexion = null;
     try{
          unaConexion = Conexion.obtenerConexion();
     }  catch (ClassNotFoundException | InstantiationException | IllegalAccessException | SQLException ex) {
            Logger.getLogger(ReservaDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        }
     
      String unaInsercion = "INSERT INTO reservas (id_pasajero, id_vuelo, fecha_de_reserva, hora_de_reserva, estado_de_reserva, cantidad_de_asientos) VALUES (?, ?, ?, ?, ?, ?)";
      
      PreparedStatement unaSentencia = null;
      try{
          unaSentencia = unaConexion.prepareStatement(unaInsercion);
      } catch (SQLException ex) {
            Logger.getLogger(ReservaDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        }
      try{
          unaSentencia.setInt(1, reserva.getPasajero().getIdPasajero());
      } catch (SQLException ex) { 
            Logger.getLogger(ReservaDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        } 
     try{
         unaSentencia.setInt(2, reserva.getVuelo().getIdVuelo());
     }  catch (SQLException ex) { 
            Logger.getLogger(ReservaDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        } 
     try{
        unaSentencia.setDate(3, (java.sql.Date) reserva.getFechaReserva());
     }  catch (SQLException ex) { 
            Logger.getLogger(ReservaDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        }
     try{
         unaSentencia.setTime(4, reserva.getHoraSalidaVuelo());
     }  catch (SQLException ex) {
            Logger.getLogger(ReservaDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        }
     try{
         unaSentencia.setString(5, reserva.getEstadoReserva().toString());
     }  catch (SQLException ex) { 
            Logger.getLogger(ReservaDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        } 
     try{
          unaSentencia.setInt(6, reserva.getCantidadAsientos());
     }  catch (SQLException ex) { 
            Logger.getLogger(ReservaDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        } 
     try{
          unaSentencia.execute();
     }  catch (SQLException ex) { 
            Logger.getLogger(ReservaDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        } 
     System.out.println("Inserción de reserva correcta");
     
     try{
          unaConexion.close();
     }  catch (SQLException ex) {
            Logger.getLogger(ReservaDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    
    }   //listo 

    @Override
    public Pasajero obtenerPasajeroPorId(int idPasajero) {
       Connection unaConexion = null; 
       try{
           unaConexion = Conexion.obtenerConexion();
       } catch (ClassNotFoundException ex) { 
            Logger.getLogger(ReservaDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            Logger.getLogger(ReservaDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            Logger.getLogger(ReservaDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(ReservaDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        } 
       
        String unaConsulta = "SELECT * FROM pasajeros WHERE id_pasajero = ?";
        
        PreparedStatement unaSentencia = null; 
        
        try{
            unaSentencia = unaConexion.prepareStatement(unaConsulta);
        } catch (SQLException ex) {
            Logger.getLogger(ReservaDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        } 
        try{
            unaSentencia.setInt(1, idPasajero);
        } catch (SQLException ex) {
            Logger.getLogger(ReservaDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        ResultSet unResultado = null;
        try{
            unResultado = unaSentencia.executeQuery();
        } catch (SQLException ex) {
            Logger.getLogger(ReservaDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        } 
        Pasajero pasajero = null;
        try{
            while (unResultado.next()) {
                pasajero = new Pasajero();
            pasajero.setIdPasajero(unResultado.getInt("id_pasajero"));
            pasajero.setNombre(unResultado.getString("nombre"));
            pasajero.setApellido(unResultado.getString("apellido"));
            pasajero.setFechaNacimiento(unResultado.getDate("fechaNacimiento"));
            pasajero.setPasaporte(unResultado.getString("pasaporte"));
            pasajero.setTelefono(unResultado.getInt("telefono"));
            pasajero.setMail(unResultado.getString("mail"));
            pasajero.setGenero(unResultado.getString("genero"));
                System.out.println("--------------------------------------------------------------");
          } 
           } catch (SQLException ex) {  
            Logger.getLogger(ReservaDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        }  
         try{
              unaConexion.close();
         } catch (SQLException ex) { 
            Logger.getLogger(ReservaDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        } 
          return pasajero;
           
     
               } //listo

    @Override
   public Vuelo obtenerVueloPorId(int idVuelo) {
    Connection unaConexion = null;
    try {
        unaConexion = Conexion.obtenerConexion();
    } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | SQLException ex) {
        Logger.getLogger(ReservaDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
    }

    String unaConsulta = "SELECT * FROM vuelos WHERE id_vuelo = ?";
    try (PreparedStatement unaSentencia = unaConexion.prepareStatement(unaConsulta)) {
        unaSentencia.setInt(1, idVuelo);

        try (ResultSet unResultado = unaSentencia.executeQuery()) {
            Vuelo vuelo = null;

            while (unResultado.next()) {
                vuelo = new Vuelo();
                vuelo.setIdVuelo(unResultado.getInt("id_vuelo"));
                vuelo.setOrigen(unResultado.getString("origen"));
                vuelo.setDestino(unResultado.getString("destino"));
                vuelo.setFechaSalida(unResultado.getDate("fecha_de_Salida"));
                vuelo.setHoraSalida(unResultado.getTime("hora_de_Salida"));
           
            }

            return vuelo;
        }
    } catch (SQLException ex) {
        Logger.getLogger(ReservaDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
    } finally {
        try {
            if (unaConexion != null) {
                unaConexion.close();
            }
        } catch (SQLException ex) {
            Logger.getLogger(ReservaDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    return null;
}//listo

   @Override
    public List<Reserva> consultarTodos() {
    List<Reserva> reservas = new ArrayList<>();
    Connection unaConexion = null;

    try {
        unaConexion = Conexion.obtenerConexion();
        String unaConsulta = "SELECT * FROM reservas";
        try (PreparedStatement unaSentencia = unaConexion.prepareStatement(unaConsulta);
             ResultSet unResultado = unaSentencia.executeQuery()) {

            while (unResultado.next()) {
                Reserva reserva = new Reserva();
                reserva.setIdReserva(unResultado.getInt("id_reserva"));
                reserva.setPasajero(obtenerPasajeroPorId(unResultado.getInt("id_pasajero")));
                reserva.setVuelo(obtenerVueloPorId(unResultado.getInt("id_vuelo")));

                // Utiliza el método getTimestamp para obtener la fecha y hora
                reserva.setFechaReserva(new Date(unResultado.getTimestamp("fecha_de_reserva").getTime()));
                reserva.setHoraSalidaVuelo(unResultado.getTime("hora_de_reserva"));
                reserva.setEstadoReserva(Reserva.EstadoReserva.valueOf(unResultado.getString("estado_de_reserva")));
                reserva.setCantidadAsientos(unResultado.getInt("cantidad_de_asientos"));

                // Puedes imprimir información sobre cada reserva
                System.out.println(reserva);

                reservas.add(reserva);
            }
        }
        
        for (Reserva reserva : reservas) {
            System.out.println("ID Reserva: " + reserva.getIdReserva());
            System.out.println("ID Pasajero: " + reserva.getPasajero().getIdPasajero());
            System.out.println("ID Vuelo: " + reserva.getVuelo().getIdVuelo());
            System.out.println("Fecha de Reserva: " + reserva.getFechaReserva());
          //  System.out.println("Hora de Salida del Vuelo: " + reserva.getHoraSalidaVuelo());
            System.out.println("Estado de Reserva: " + reserva.getEstadoReserva());
            System.out.println("Cantidad de Asientos: " + reserva.getCantidadAsientos());
            System.out.println("-----------------------");
        }

    } catch (SQLException | ClassNotFoundException | InstantiationException | IllegalAccessException ex) {
        // Puedes imprimir mensajes de error
        ex.printStackTrace();
    } finally {
        try {
            if (unaConexion != null) {
                unaConexion.close();
            }
        } catch (SQLException ex) {
            // Puedes imprimir mensajes de error
            ex.printStackTrace();
        }
    }

    return reservas;
}

    @Override
   public ArrayList<Reserva> cargarLista() {
    ArrayList<Reserva> lista = new ArrayList<Reserva>();  
    Connection unaConexion = null;

    try {
        unaConexion = Conexion.obtenerConexion();
        String unaConsulta = "SELECT * FROM reservas";
        java.sql.Statement unaSentencia = unaConexion.createStatement();
        ResultSet unResultado = unaSentencia.executeQuery(unaConsulta);

        while (unResultado.next()) {
            Reserva reserva = new Reserva();
            reserva.setIdReserva(unResultado.getInt("id_reserva"));
            reserva.setPasajero(obtenerPasajeroPorId(unResultado.getInt("id_pasajero")));
            reserva.setVuelo(obtenerVueloPorId(unResultado.getInt("id_vuelo")));
            reserva.setFechaReserva(new Date(unResultado.getTimestamp("fecha_de_reserva").getTime()));
          //  reserva.setHoraSalidaVuelo(unResultado.getTime("hora_de_reserva_alias")); // Asegúrate de tener este método en la clase Reserva
            reserva.setEstadoReserva(Reserva.EstadoReserva.valueOf(unResultado.getString("estado_de_reserva")));
            reserva.setCantidadAsientos(unResultado.getInt("cantidad_de_asientos"));

            lista.add(reserva);
        }
        
        // Agrega el bucle for para imprimir la información de cada reserva
        for (Reserva reserva : lista) {
            System.out.println("ID Reserva: " + reserva.getIdReserva());
            System.out.println("ID Pasajero: " + reserva.getPasajero().getIdPasajero());
            System.out.println("ID Vuelo: " + reserva.getVuelo().getIdVuelo());
            System.out.println("Fecha de Reserva: " + reserva.getFechaReserva());
         //   System.out.println("Hora de Salida del Vuelo: " + reserva.getHoraSalidaVuelo()); // Asegúrate de tener este método en la clase Reserva
            System.out.println("Estado de Reserva: " + reserva.getEstadoReserva());
            System.out.println("Cantidad de Asientos: " + reserva.getCantidadAsientos());
            System.out.println("-----------------------");
        }

    } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | SQLException ex) {
        Logger.getLogger(ReservaDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
    } finally {
        try {
            if (unaConexion != null) {
                unaConexion.close();
            }
        } catch (SQLException ex) {
            Logger.getLogger(VueloDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    return lista;
}
    
    
}
