
package PasajeroDAO;
import java.util.Date;
import viajes.Conexion;


public class test {

   
    public static void main(String[] args) {
          
               
        
       PasajeroDAOIMPLS p = new PasajeroDAOIMPLS();
        
                                        // Crea un objeto Date con la fecha 1999/09/10
//        Date fechaNacimiento = new Date(99, 8, 10);
        
        // Utiliza el constructor correcto de Pasajero
//        Pasajero p1 = new Pasajero(8, "Mauro", "Massa", fechaNacimiento, "K334411", 44123112, "mauro@gmail.com", "Masculino");
        
//        p.consultarUno("Mauro");
        
        // Agrega una línea para imprimir algo después de la consulta
//        System.out.println("Consulta completada");
      p.cargarLista();
    }
    
}
