
package ReservaDAO;

import PasajeroDAO.Pasajero;
import viajes.Conexion;
import ReservaDAO.ReservaDAOIMPLS;
import PasajeroDAO.PasajeroDAOIMPLS;
import VueloDAO.Vuelo;
import java.util.Date;
import java.sql.Time;  

public class TestReserva {

    
    public static void main(String[] args) {
        // TODO code application logic here
                ReservaDAOIMPLS r = new ReservaDAOIMPLS();
//
//           Pasajero pasajero = new Pasajero();
//        Vuelo vuelo = new Vuelo();
//
//        pasajero.setIdPasajero(1);
//        vuelo.setIdVuelo(1);
//
//        // Crear una fecha y hora de reserva
//        Date fechaReserva = java.sql.Date.valueOf("2023-11-01");
//        Time horaSalida = java.sql.Time.valueOf("14:30:00");
//
//        // Crear una reserva
//        Reserva reserva = new Reserva(9, pasajero, vuelo, fechaReserva, horaSalida, Reserva.EstadoReserva.Confirmado, 2);
//
//        // Insertar la reserva
//        r.insertar(reserva);

         r.obtenerVueloPorId(3);
    }
    }
    

