package PasajeroDAO;



import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import viajes.Conexion;
import PasajeroDAO.DAOpasajero;
import PasajeroDAO.Pasajero;
import VueloDAO.Vuelo;
import ReservaDAO.Reserva;



public class PasajeroDAOIMPLS implements DAOpasajero {

    @Override
    public void consultarUno(String nombre) {
        Connection unaConexion = null;
        try {
        unaConexion = Conexion.obtenerConexion();
    } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | SQLException ex) {
        Logger.getLogger(PasajeroDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
    }

    String unaConsulta = "select * from pasajeros where nombre = '" + nombre + "'";

    Statement unaSentencia = null;
    try {
        unaSentencia = unaConexion.createStatement();
    } catch (SQLException ex) {
        Logger.getLogger(PasajeroDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
    }

    ResultSet unResultado = null;
    try {
        unResultado = unaSentencia.executeQuery(unaConsulta);
    } catch (SQLException ex) {
        Logger.getLogger(PasajeroDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
    }
    try {
        if (unResultado.next()) {
            System.out.println("Nombre: " + unResultado.getString("nombre"));
            System.out.println("Apellido: " + unResultado.getString("apellido"));
            System.out.println("Fecha de nacimiento: " + unResultado.getString("fechaNacimiento"));
            System.out.println("Numero de pasaporte: " + unResultado.getString("pasaporte"));
            System.out.println("Telefono " + unResultado.getString("telefono"));
            System.out.println("Mail: " + unResultado.getString("mail"));
            System.out.println("Genero: " + unResultado.getString("genero"));
            System.out.println("-------------------------------------------");
        } else {
            System.out.println("No se encontraron resultados para el nombre: " + nombre);
        }
    } catch (SQLException ex) {
        Logger.getLogger(PasajeroDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
    } finally {
        try {
            if (unaConexion != null) {
                unaConexion.close();
            }
        } catch (SQLException ex) {
            Logger.getLogger(PasajeroDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    } // listo 

    @Override
    public void insertar(Pasajero p) {
    Connection unaConexion = null;
            try {
        try {
            unaConexion = Conexion.obtenerConexion();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(PasajeroDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            Logger.getLogger(PasajeroDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            Logger.getLogger(PasajeroDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        }

        String unaInsercion = "insert into pasajeros(nombre, apellido, fechaNacimiento, pasaporte, telefono, mail, genero) values (?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement unaSentencia = unaConexion.prepareStatement(unaInsercion, Statement.RETURN_GENERATED_KEYS)) {
            unaSentencia.setString(1, p.getNombre());
            unaSentencia.setString(2, p.getApellido());
            unaSentencia.setDate(3, new java.sql.Date(p.getFechaNacimiento().getTime()));
            unaSentencia.setString(4, p.getPasaporte());
            unaSentencia.setInt(5, p.getTelefono());
            unaSentencia.setString(6, p.getMail());
            unaSentencia.setString(7, p.getGenero());

            int filasAfectadas = unaSentencia.executeUpdate();

            if (filasAfectadas > 0) {
                try (ResultSet generatedKeys = unaSentencia.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        int idGenerado = generatedKeys.getInt(1);
                        System.out.println("ID del nuevo pasajero: " + idGenerado);
                        p.setIdPasajero(idGenerado);
                    }
                }
                System.out.println("Inserción correcta");
            } else {
                System.out.println("No se pudo insertar el pasajero");
            }
        }
    } catch (SQLException ex) {
        Logger.getLogger(PasajeroDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        System.out.println("Error SQL: " + ex.getMessage());
    } finally {
        try {
            if (unaConexion != null) {
                unaConexion.close();
            }
        } catch (SQLException ex) {
            Logger.getLogger(PasajeroDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Error al cerrar la conexión: " + ex.getMessage());
        }
    }
        
        }  //listo
            
    @Override
    public void actualizar(String nombreAnterior, String nombreNuevo) {
         Connection unaConexion = null;   
            try {
                unaConexion = Conexion.obtenerConexion();
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(PasajeroDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
            } catch (InstantiationException ex) {
                Logger.getLogger(PasajeroDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IllegalAccessException ex) {
                Logger.getLogger(PasajeroDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SQLException ex) {
                Logger.getLogger(PasajeroDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
            }
            
             String unaActualizacion = "update pasajeros set nombre = ? where nombre = ?";
            
             PreparedStatement unaSentencia = null;
             try {
                   unaSentencia = unaConexion.prepareStatement(unaActualizacion);
        } catch (SQLException ex) {
                     Logger.getLogger(PasajeroDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        }
             try {
             unaSentencia.setString(1, nombreNuevo);
        } catch (SQLException ex) {
              Logger.getLogger(PasajeroDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        }
             try {
               unaSentencia.setString(2, nombreAnterior);
        } catch (SQLException ex) {
              Logger.getLogger(PasajeroDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        }
             try {
            unaSentencia.execute();
        } catch (SQLException ex) {
              Logger.getLogger(PasajeroDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        }
               System.out.println("Actualizacion correcta");
               
               try {
            unaConexion.close();
        } catch (SQLException ex) {
             Logger.getLogger(PasajeroDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        }
               
         } //listo 

    @Override
    public void eliminar(String apellido) {
         Connection unaConexion = null;
       try{
                   unaConexion = Conexion.obtenerConexion();
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(PasajeroDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
            } catch (InstantiationException ex) {
                Logger.getLogger(PasajeroDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IllegalAccessException ex) {
                Logger.getLogger(PasajeroDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SQLException ex) {
                Logger.getLogger(PasajeroDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
            }
                 
               String unaEliminacion = "delete from pasajeros where apellido = ?";
       
                 PreparedStatement unaSentencia = null;
        try {
               unaSentencia = unaConexion.prepareStatement(unaEliminacion);
        } catch (Exception ex) {
            Logger.getLogger(PasajeroDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            unaSentencia.setString(1, apellido);
        } catch (SQLException ex) {
             Logger.getLogger(PasajeroDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            unaSentencia.execute();
        } catch (SQLException ex) {
             Logger.getLogger(PasajeroDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        }
        
         System.out.println("Eliminacion correcta");
        
        try {
            unaConexion.close();
        } catch (SQLException ex) {
             Logger.getLogger(PasajeroDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        }
        
       } //listo
    
    @Override
    public  List<Pasajero> consultarTodos() {
        Connection unaConexion = null;
        List<Pasajero> lista = new ArrayList<>();
            try {
                unaConexion = Conexion.obtenerConexion();
            } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | SQLException ex) {
                Logger.getLogger(PasajeroDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            String unaConsulta =  "select * from pasajeros";
            
             Statement unaSentencia = null;
        try {
            unaSentencia = unaConexion.createStatement();    
        } catch (SQLException ex) {
            Logger.getLogger(PasajeroDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        } 
        
        ResultSet unResultado = null;
           try {
               unResultado = unaSentencia.executeQuery(unaConsulta);
           } catch (SQLException ex) {
            Logger.getLogger(PasajeroDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        }
           
           
            try {
                while(unResultado.next()){
                    // agregar souts correspondientes
                   System.out.println("Nombre: " + unResultado.getString("nombre"));
                   System.out.println("Apellido: " + unResultado.getString("apellido"));
                   System.out.println("Fecha de nacimiento: " + unResultado.getString("fechaNacimiento"));
                   System.out.println("Numero de pasaporte: " + unResultado.getString("pasaporte"));
                   System.out.println("Telefono " + unResultado.getString("telefono"));
                   System.out.println("Mail: " + unResultado.getString("mail"));
                   System.out.println("Genero: " + unResultado.getString("genero"));
                   System.out.println("-------------------------------------------");
                }
            } catch (SQLException ex) {
                Logger.getLogger(PasajeroDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
            }
           
            try {
            unaConexion.close();
        } catch (SQLException ex) {
                Logger.getLogger(PasajeroDAOIMPLS.class.getName()).log(Level.SEVERE,null,ex);
        }
 {
            }
            return lista;
              
               
  
                    } //fin consultartodos

    @Override
  public ArrayList<Pasajero> cargarLista() {
    ArrayList<Pasajero> lista = new ArrayList<>();
    Connection unaConexion = null;

    try {
        unaConexion = Conexion.obtenerConexion();
        String unaConsulta = "select * from pasajeros"; // Cambié el nombre de la tabla a pasajeros
        Statement unaSentencia = unaConexion.createStatement();
        ResultSet unResultado = unaSentencia.executeQuery(unaConsulta);

        while (unResultado.next()) {
            int idPasajero = unResultado.getInt("id_pasajero");
            String nombre = unResultado.getString("nombre");
            String apellido = unResultado.getString("apellido");
            Date fechaNacimiento = unResultado.getDate("fechaNacimiento");
            String pasaporte = unResultado.getString("pasaporte");
            int telefono = unResultado.getInt("telefono");
            String mail = unResultado.getString("mail");
            String genero = unResultado.getString("genero");

            Pasajero pasajero = new Pasajero(idPasajero, nombre, apellido, fechaNacimiento, pasaporte, telefono, mail, genero);
            lista.add(pasajero);
        }

        // Puedes imprimir la lista aquí si es necesario
        for (Pasajero pasajero : lista) {
            System.out.println("ID Pasajero: " + pasajero.getIdPasajero());
            System.out.println("Nombre: " + pasajero.getNombre());
            System.out.println("Apellido: " + pasajero.getApellido());
            System.out.println("Fecha de Nacimiento: " + pasajero.getFechaNacimiento());
            System.out.println("Pasaporte: " + pasajero.getPasaporte());
            System.out.println("Teléfono: " + pasajero.getTelefono());
            System.out.println("Correo Electrónico: " + pasajero.getMail());
            System.out.println("Género: " + pasajero.getGenero());
            System.out.println("-----------------------");
        }
    } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | SQLException ex) {
        Logger.getLogger(PasajeroDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
    } finally {
        try {
            if (unaConexion != null) {
                unaConexion.close();
            }
        } catch (SQLException ex) {
            Logger.getLogger(PasajeroDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    return lista;
}
}

    
               //final
    



    


