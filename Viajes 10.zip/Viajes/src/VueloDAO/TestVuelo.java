
package VueloDAO;
import java.util.Date;
import viajes.Conexion;

public class TestVuelo {

    
    public static void main(String[] args) {
        
        VueloDAOIMPLS v = new VueloDAOIMPLS(){};
      //   v.cargarLista();
     //   v.consultarUno("AA101");
     //     v.consultarTodos();
       
     //insercion de datos
//            Vuelo nuevoVuelo = new Vuelo();
//            nuevoVuelo.setVuelo("AA102");
//            nuevoVuelo.setOrigen("Nueva York");
//            nuevoVuelo.setDestino("Los Ángeles");

    // Usar clases java.sql.Date y java.sql.Time
//            nuevoVuelo.setFechaSalida(java.sql.Date.valueOf("2023-11-01"));
//            nuevoVuelo.setHoraSalida(java.sql.Time.valueOf("14:30:00"));
//            nuevoVuelo.setAsientos(200);

        
     
//         v.insertar(nuevoVuelo);

         // Datos para la actualización
         
//       String vueloAnterior = "AA101"; // Reemplaza con el valor correcto
//       String vueloNuevo = "AA201"; // Reemplaza con el valor correcto
//////
//////
//           v.actualizar(vueloAnterior, vueloNuevo);
//     
   //  v.consultarUno("AA201");    
   
      v.cargarLista();
   
   
    }
    
}
