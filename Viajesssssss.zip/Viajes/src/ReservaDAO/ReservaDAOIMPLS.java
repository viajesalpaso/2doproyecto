
package ReservaDAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import viajes.Conexion;
import ReservaDAO.Reserva;
import PasajeroDAO.Pasajero;
import VueloDAO.Vuelo;

public class ReservaDAOIMPLS implements DAOreserva{

    @Override
    public void insertar(Reserva reserva) {
    Connection unaConexion = null;
     try{
          unaConexion = Conexion.obtenerConexion();
     }  catch (ClassNotFoundException ex) {
            Logger.getLogger(ReservaDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            Logger.getLogger(ReservaDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            Logger.getLogger(ReservaDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(ReservaDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        }
     
      String unaInsercion = "INSERT INTO reservas (id_pasajero, id_vuelo, fechaReserva, estadoReserva, cantidadAsientos) VALUES (?, ?, ?, ?, ?)";
      
      PreparedStatement unaSentencia = null;
      try{
          unaSentencia = unaConexion.prepareStatement(unaInsercion);
      } catch (SQLException ex) {
            Logger.getLogger(ReservaDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        }
      try{
          unaSentencia.setInt(1, reserva.getPasajero().getIdPasajero());
      } catch (SQLException ex) { 
            Logger.getLogger(ReservaDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        } 
     try{
         unaSentencia.setInt(2, reserva.getVuelo().getIdVuelo());
     }  catch (SQLException ex) { 
            Logger.getLogger(ReservaDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        } 
     try{
        unaSentencia.setDate(3, (java.sql.Date) reserva.getFechaReserva());
     }  catch (SQLException ex) { 
            Logger.getLogger(ReservaDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        } 
     try{
         unaSentencia.setString(4, reserva.getEstadoReserva().toString());
     }  catch (SQLException ex) { 
            Logger.getLogger(ReservaDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        } 
     try{
          unaSentencia.setInt(5, reserva.getCantidadAsientos());
     }  catch (SQLException ex) { 
            Logger.getLogger(ReservaDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        } 
     try{
          unaSentencia.execute();
     }  catch (SQLException ex) { 
            Logger.getLogger(ReservaDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        } 
     System.out.println("Inserción de reserva correcta");
     
     try{
          unaConexion.close();
     }  catch (SQLException ex) {
            Logger.getLogger(ReservaDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    
    }   //listo 

    @Override
    public Pasajero obtenerPasajeroPorId(int idPasajero) {
       Connection unaConexion = null; 
       try{
           unaConexion = Conexion.obtenerConexion();
       } catch (ClassNotFoundException ex) { 
            Logger.getLogger(ReservaDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            Logger.getLogger(ReservaDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            Logger.getLogger(ReservaDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(ReservaDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        } 
       
        String unaConsulta = "SELECT * FROM pasajeros WHERE id_pasajero = ?";
        
        PreparedStatement unaSentencia = null; 
        
        try{
            unaSentencia = unaConexion.prepareStatement(unaConsulta);
        } catch (SQLException ex) {
            Logger.getLogger(ReservaDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        } 
        try{
            unaSentencia.setInt(1, idPasajero);
        } catch (SQLException ex) {
            Logger.getLogger(ReservaDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        ResultSet unResultado = null;
        try{
            unResultado = unaSentencia.executeQuery();
        } catch (SQLException ex) {
            Logger.getLogger(ReservaDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        } 
        Pasajero pasajero = null;
        try{
            while (unResultado.next()) {
                pasajero = new Pasajero();
            pasajero.setIdPasajero(unResultado.getInt("id_pasajero"));
            pasajero.setNombre(unResultado.getString("nombre"));
            pasajero.setApellido(unResultado.getString("apellido"));
            pasajero.setFechaNacimiento(unResultado.getDate("fechaNacimiento"));
            pasajero.setPasaporte(unResultado.getString("pasaporte"));
            pasajero.setTelefono(unResultado.getInt("telefono"));
            pasajero.setMail(unResultado.getString("mail"));
            pasajero.setGenero(unResultado.getString("genero"));
          } 
           } catch (SQLException ex) {  
            Logger.getLogger(ReservaDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        }  
         try{
              unaConexion.close();
         } catch (SQLException ex) { 
            Logger.getLogger(ReservaDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        } 
          return pasajero;
           
     
               } //listo

    @Override
    public Vuelo obtenerVueloPorId(int idVuelo) {
        Connection unaConexion = null;
        try{
            unaConexion = Conexion.obtenerConexion();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ReservaDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            Logger.getLogger(ReservaDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            Logger.getLogger(ReservaDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(ReservaDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        } 
        
         String unaConsulta = "SELECT * FROM vuelos WHERE id_vuelo = ?";
         PreparedStatement unaSentencia = null; 
         try{
             unaSentencia = unaConexion.prepareStatement(unaConsulta);
         } catch (SQLException ex) { 
            Logger.getLogger(ReservaDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        } 
         try{
             unaSentencia.setInt(1, idVuelo);
         } catch (SQLException ex) { 
            Logger.getLogger(ReservaDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        } 
         
         ResultSet unResultado = null;
         try{
             unResultado = unaSentencia.executeQuery();
         } catch (SQLException ex) { 
            Logger.getLogger(ReservaDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        } 
         
         Vuelo vuelo = null;
         try{
             while (unResultado.next()); {
            vuelo = new Vuelo();
            vuelo.setIdVuelo(unResultado.getInt("id_vuelo"));
            vuelo.setVuelo(unResultado.getString("vuelo"));
            vuelo.setOrigen(unResultado.getString("origen"));
            vuelo.setDestino(unResultado.getString("destino"));
            vuelo.setFechaSalida(unResultado.getDate("fechaSalida"));
            vuelo.setHoraSalida(unResultado.getTime("horaSalida"));
            vuelo.setAsientos(unResultado.getInt("asientos"));
        }
         } catch (SQLException ex) { 
            Logger.getLogger(ReservaDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        } 
        
         try{
             unaConexion.close();
         } catch (SQLException ex) { 
            Logger.getLogger(ReservaDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        } 
         
         return vuelo;
        
    } //listo

   @Override
    public List<Reserva> obtenerTodas() {
    List<Reserva> reservas = new ArrayList<>();
    Connection unaConexion = null;
    PreparedStatement unaSentencia = null;  // Mueve la declaración aquí

    try {
        unaConexion = Conexion.obtenerConexion();
        String unaConsulta = "SELECT * FROM reservas";
        unaSentencia = unaConexion.prepareStatement(unaConsulta);  // Inicializa aquí
        ResultSet unResultado = unaSentencia.executeQuery();

        while (unResultado.next()) {
            Reserva reserva = new Reserva();
            reserva.setIdReserva(unResultado.getInt("id_reserva"));
            reserva.setPasajero(obtenerPasajeroPorId(unResultado.getInt("id_pasajero")));
            reserva.setVuelo(obtenerVueloPorId(unResultado.getInt("id_vuelo")));

            // Utiliza el método getTimestamp para obtener la fecha y hora
            reserva.setFechaReserva(new Date(unResultado.getTimestamp("fechaReserva").getTime()));

            reserva.setEstadoReserva(Reserva.EstadoReserva.valueOf(unResultado.getString("estadoReserva")));
            reserva.setCantidadAsientos(unResultado.getInt("cantidadAsientos"));

            reservas.add(reserva);
        }
    } catch (SQLException ex) {
        Logger.getLogger(ReservaDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
    }   catch (ClassNotFoundException ex) {
            Logger.getLogger(ReservaDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            Logger.getLogger(ReservaDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            Logger.getLogger(ReservaDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
        try {
            if (unaConexion != null) {
                unaConexion.close();
            }
            if (unaSentencia != null) {
                unaSentencia.close();
            }
        } catch (SQLException ex) {
            Logger.getLogger(ReservaDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    return reservas;
}
    
}
