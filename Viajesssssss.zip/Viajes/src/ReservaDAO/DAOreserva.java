
package ReservaDAO;

import java.util.List;
import ReservaDAO.Reserva;
import PasajeroDAO.Pasajero;
import VueloDAO.Vuelo;


public interface DAOreserva {
    
    void insertar(Reserva reserva);
    
    Pasajero obtenerPasajeroPorId(int idPasajero);
    
    Vuelo obtenerVueloPorId(int idVuelo);
    
    List<Reserva> obtenerTodas();
    
    
    
    
    
    
    
}
