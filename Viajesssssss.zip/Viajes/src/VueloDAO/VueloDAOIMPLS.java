package VueloDAO;


import PasajeroDAO.Pasajero;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import viajes.Conexion;
import VueloDAO.DAOvuelo;
import VueloDAO.Vuelo;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.sql.Time;

public abstract class VueloDAOIMPLS implements DAOvuelo{

    public void consultarUno(String vuelo) {
    Connection unaConexion = null;
       try{
           unaConexion = Conexion.obtenerConexion();
       } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | SQLException ex) {
            Logger.getLogger(VueloDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        }
        
         String unaConsulta = "select * from vuelos where numero_de_vuelo = '" + vuelo + "'";
         
          Statement unaSentencia = null;
           try {
            unaSentencia = unaConexion.createStatement();
        } catch (SQLException ex) {
            Logger.getLogger(VueloDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        } 
         
        ResultSet unResultado = null;
        try {
            unResultado = unaSentencia.executeQuery(unaConsulta);
        } catch (SQLException ex) {
            Logger.getLogger(VueloDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        }   
       
       try {
            if (unResultado.next()) {
                 System.out.println("Número de Vuelo: " + unResultado.getString("numero_de_vuelo"));
        System.out.println("Origen: " + unResultado.getString("origen"));
        System.out.println("Destino: " + unResultado.getString("destino"));
        System.out.println("Fecha de Salida: " + unResultado.getDate("fechaSalida"));
        System.out.println("Hora de Salida: " + unResultado.getTime("horaSalida"));
        System.out.println("Asientos: " + unResultado.getInt("asientos"));
        System.out.println("--------------------------------");
            }
        } catch (SQLException ex) {
            Logger.getLogger(VueloDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        }
       
        try {
            unaConexion.close();
        } catch (SQLException ex) {
            Logger.getLogger(VueloDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        }
    }     // listo

    @Override
public void insertar(Vuelo v) {
    Connection unaConexion = null;
    PreparedStatement unaSentencia = null;

    try {
        unaConexion = Conexion.obtenerConexion();
        String unaInsercion = "INSERT INTO vuelos (vuelo, origen, destino, fechaSalida, horaSalida, asientos) VALUES (?, ?, ?, ?, ?, ?)";
        unaSentencia = unaConexion.prepareStatement(unaInsercion);

        unaSentencia.setString(1, v.getVuelo());
        unaSentencia.setString(2, v.getOrigen());
        unaSentencia.setString(3, v.getDestino());
        unaSentencia.setDate(4, v.getFechaSalida());
        unaSentencia.setTime(5, v.getHoraSalida());
        unaSentencia.setInt(6, v.getAsientos());

        unaSentencia.execute();
        System.out.println("Inserción correcta");
    } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | SQLException ex) {
        Logger.getLogger(VueloDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
    } finally {
        try {
            if (unaSentencia != null) {
                unaSentencia.close();
            }
            if (unaConexion != null) {
                unaConexion.close();
            }
        } catch (SQLException ex) {
            Logger.getLogger(VueloDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
} // listo 

 @Override
public void actualizar(String vueloAnterior, String vueloNuevo) {
    try {
        Connection unaConexion = Conexion.obtenerConexion();

        String consultaObtenerVuelo = "SELECT * FROM vuelos WHERE vuelo = ?";
        try (PreparedStatement sentenciaObtenerVuelo = unaConexion.prepareStatement(consultaObtenerVuelo)) {
            sentenciaObtenerVuelo.setString(1, vueloNuevo);

            try (ResultSet resultado = sentenciaObtenerVuelo.executeQuery()) {
                if (resultado.next()) {
                    Vuelo nuevoVuelo = new Vuelo();
                    nuevoVuelo.setIdVuelo(resultado.getInt("idVuelo"));
                    nuevoVuelo.setVuelo(resultado.getString("vuelo"));
                    nuevoVuelo.setOrigen(resultado.getString("origen"));
                    nuevoVuelo.setDestino(resultado.getString("destino"));
                    nuevoVuelo.setFechaSalida(resultado.getDate("fechaSalida"));
                    nuevoVuelo.setHoraSalida(resultado.getTime("horaSalida"));
                    nuevoVuelo.setAsientos(resultado.getInt("asientos"));

                    String unaActualizacion = "UPDATE vuelos SET vuelo = ?, origen = ?, destino = ?, fechaSalida = ?, horaSalida = ?, asientos = ? WHERE idVuelo = ?";
                    try (PreparedStatement unaSentencia = unaConexion.prepareStatement(unaActualizacion)) {
                        unaSentencia.setString(1, nuevoVuelo.getVuelo());
                        unaSentencia.setString(2, nuevoVuelo.getOrigen());
                        unaSentencia.setString(3, nuevoVuelo.getDestino());
                        unaSentencia.setDate(4, nuevoVuelo.getFechaSalida());
                        unaSentencia.setTime(5, nuevoVuelo.getHoraSalida());
                        unaSentencia.setInt(6, nuevoVuelo.getAsientos());
                        unaSentencia.setInt(7, nuevoVuelo.getIdVuelo());

                        unaSentencia.executeUpdate();
                        System.out.println("Actualización correcta");
                    }
                } else {
                    System.out.println("El vuelo no existe");
                }
            }
        }

        unaConexion.close();
    } catch (SQLException | ClassNotFoundException | InstantiationException | IllegalAccessException ex) {
        ex.printStackTrace();
    }
} // listo

     @Override
    public void eliminar(int idVuelo) {
        Connection unaConexion = null;
        try{
            unaConexion = (Connection) Conexion.obtenerConexion();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(VueloDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            Logger.getLogger(VueloDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            Logger.getLogger(VueloDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(VueloDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        } 
        
         String unaEliminacion = "DELETE FROM vuelos WHERE idVuelo = ?";
         
         PreparedStatement unaSentencia = null;
         try{
             unaSentencia = unaConexion.prepareStatement(unaEliminacion);
         } catch (SQLException ex) { 
            Logger.getLogger(VueloDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        } 
         
         try{
             unaSentencia.setInt(1, idVuelo);
         } catch (SQLException ex) { 
            Logger.getLogger(VueloDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        } 
         
         try{
             unaSentencia.execute();
         } catch (SQLException ex) { 
            Logger.getLogger(VueloDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        } 
         
          System.out.println("Eliminación correcta");
          
          try{
              unaConexion.close();
          } catch (SQLException ex) {
            Logger.getLogger(VueloDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
    }  // listo 

   @Override
public ArrayList<Vuelo> cargarLista() {
    ArrayList<Vuelo> lista = new ArrayList<>();   
    Connection unaConexion = null;

    try {
        unaConexion = Conexion.obtenerConexion();
        String unaConsulta = "SELECT * FROM Vuelos";
        Statement unaSentencia = unaConexion.createStatement();
        ResultSet unResultado = unaSentencia.executeQuery(unaConsulta);

        while (unResultado.next()) {
            int idVuelo = unResultado.getInt("idVuelo");
            String nombreVuelo = unResultado.getString("nombreVuelo");
            String origen = unResultado.getString("origen");
            String destino = unResultado.getString("destino");
            Date fechaSalida = unResultado.getDate("fechaSalida");
            Time horaSalida = unResultado.getTime("horaSalida");
            int asientos = unResultado.getInt("asientos");

            Vuelo vuelo = new Vuelo(idVuelo, nombreVuelo, origen, destino, (java.sql.Date) fechaSalida, horaSalida, asientos);
            lista.add(vuelo);
        }

        for (Vuelo vuelo : lista) {
            System.out.println("ID Vuelo: " + vuelo.getIdVuelo());
            System.out.println("Nombre Vuelo: " + vuelo);
            System.out.println("Origen: " + vuelo.getOrigen());
            System.out.println("Destino: " + vuelo.getDestino());
            System.out.println("Fecha de Salida: " + vuelo.getFechaSalida());
            System.out.println("Hora de Salida: " + vuelo.getHoraSalida());
            System.out.println("Asientos: " + vuelo.getAsientos());
            System.out.println("-----------------------");
        }

    } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | SQLException ex) {
        Logger.getLogger(VueloDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
    } finally {
        try {
            if (unaConexion != null) {
                unaConexion.close();
            }
        } catch (SQLException ex) {
            Logger.getLogger(VueloDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    return lista;
}

    @Override
  public List<Vuelo> consultarTodos() {
    List<Vuelo> lista = new ArrayList<>();
    try (Connection unaConexion = Conexion.obtenerConexion();
         Statement unaSentencia = unaConexion.createStatement();
         ResultSet unResultado = unaSentencia.executeQuery("SELECT * FROM vuelos")) {

        while (unResultado.next()) {
            int idVuelo = unResultado.getInt("id_vuelo");
            String numeroVuelo = unResultado.getString("numero_de_vuelo");
            String origen = unResultado.getString("origen");
            String destino = unResultado.getString("destino");
            Date fechaSalida = unResultado.getDate("fecha_de_salida");
            Time horaSalida = unResultado.getTime("hora_de_salida");
            int asientos = unResultado.getInt("capacidad_total_de_asientos");

            Vuelo vueloItem = new Vuelo(idVuelo, numeroVuelo, origen, destino, (java.sql.Date) fechaSalida, horaSalida, asientos);
            lista.add(vueloItem);
        }

        for (Vuelo vueloItem : lista) {
            System.out.println("ID Vuelo: " + vueloItem.getIdVuelo());
            System.out.println("Número de Vuelo: " + vueloItem.getVuelo());
            System.out.println("Origen: " + vueloItem.getOrigen());
            System.out.println("Destino: " + vueloItem.getDestino());
            System.out.println("Fecha de Salida: " + vueloItem.getFechaSalida());
            System.out.println("Hora de Salida: " + vueloItem.getHoraSalida());
            System.out.println("Asientos: " + vueloItem.getAsientos());
            System.out.println("-----------------------");
        }

    } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | SQLException ex) {
        Logger.getLogger(VueloDAOIMPLS.class.getName()).log(Level.SEVERE, null, ex);
    }

    return lista;
}


    
   
}
