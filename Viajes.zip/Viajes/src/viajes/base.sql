create database viajes;

use viajes;

create table vuelos (

id_vuelo int auto_increment primary key,
vuelo varchar (6) not null,
origen   varchar (15) not null,
destino varchar (40) not null,
fechaSalida date,
horaSalida time,
asientos int

);

create table pasajeros (

id_pasajero int auto_increment primary key,
nombre varchar (20) not null,
apellido varchar (20) not null,
fechaNacimiento date,
genero varchar(10),
pasaporte varchar (20),
telefono int,
mail varchar (30)
);

create table reservas (

id_reserva int auto_increment primary key,
id_pasajero int,
id_vuelo int,
fechaReserva date,
estadoReserva enum ('Confirmado', 'Pendiente', 'Cancelado'),
cantidadAsientos int,


foreign key (id_pasajero) references pasajeros(id_pasajero),
foreign key (id_vuelo) references vuelos(id_vuelo)

);

INSERT INTO Pasajeros (nombre, apellido, fechaNacimiento, genero, pasaporte, Telefono, mail)
VALUES
('Juan', 'Pérez', '1990-05-15', 'Masculino', '12345', '5551234', 'juan.perez@email.com'),
('María', 'Rodríguez', '1985-08-20', 'Femenino', '67890', '5555678', 'maria.rodriguez@email.com'),
('Carlos', 'López', '1995-03-10', 'Masculino', '54321', '5554321', 'carlos.lopez@email.com');

INSERT INTO Vuelos (vuelo, origen, destino, fechaSalida, horaSalida, asientos)
VALUES
('AA101', 'Nueva York', 'Los Ángeles', '2023-10-10', '08:00:00', 150),
('BA202', 'Londres', 'París', '2023-10-12', '09:30:00', 200),
('CA303', 'Pekín', 'Shanghái', '2023-10-15', '11:15:00', 100);

INSERT INTO Reservas (id_pasajero, id_vuelo, fechaReserva, estadoReserva, cantidadAsientos)
VALUES
(1, 1, '2023-10-05', 'Confirmado', 2),
(2, 2, '2023-10-06', 'Pendiente', 1),
(3, 3, '2023-10-07', 'Cancelado', 4);

select * from pasajeros;
select * from vuelos;
select * from reservas;