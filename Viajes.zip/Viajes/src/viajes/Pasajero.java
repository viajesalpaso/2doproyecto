

package viajes;

import java.util.Date;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.util.ArrayList;


public final class Pasajero {
    
    // atributos
    private int idPasajero;
    private String nombre;
    private String apellido;
    private Date fechaNacimiento;
    private String pasaporte;
    private int telefono;
    private String mail;
    private String genero;

    //constructores
    public Pasajero() {
    }

    public Pasajero(int idPasajero, String nombre, String apellido, Date fecha, String pasaporte, int telefono, String mail, String genero) {
        this.setIdPasajero(idPasajero);
        this.setNombre(nombre);
        this.setApellido(apellido);
        this.setFechaNacimiento(fechaNacimiento);
        this.setPasaporte(pasaporte);
        this.setTelefono(telefono);
        this.setMail(mail);
        this.setGenero(genero);
        
    }
    
    
    
    

    // getters and setters
    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    
    public int getTelefono() {
        return telefono;
    }

    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }

    public String getPasaporte() {
        return pasaporte;
    }

    public void setPasaporte(String pasaporte) {
        this.pasaporte = pasaporte;
    }



    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public Date getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(Date fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }
  
    
    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    

    public int getIdPasajero() {
        return idPasajero;
    }

    public void setIdPasajero(int idPasajero) {
        this.idPasajero = idPasajero;
    }

    
    // metodos

    @Override
    public String toString() {
        return idPasajero + " - " + nombre + " - " + apellido + " - " + fechaNacimiento + " - " + pasaporte + " - " + telefono + " - " + mail + " - " + genero;
    }
    
    // metodos de acceso a datos ABMC (CRUD)
    public static void consultarTodos() throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        // creo una conexion
        Connection unaConexion = Conexion.obtenerConexion();
        
        // armo la query
        String unaConsulta = "select * from pasajeros";
        
        // creo una sentencia que ejecute la query 
        Statement unaSentencia = unaConexion.createStatement();
        
        // Ejecuto la query y guardo el resultado
        ResultSet unResultado = unaSentencia.executeQuery(unaConsulta);
        
        // recorro el resultado y muetro en Consola
        while (unResultado.next()) {
            System.out.println("Nombre: " + unResultado.getString("nombre"));
            System.out.println("Apellido: " + unResultado.getString("apellido"));
            System.out.println("Fecha de nacimiento: " + unResultado.getString("fechaNacimiento"));
            System.out.println("Numero de pasaporte: " + unResultado.getString("pasaporte"));
            System.out.println("Telefono " + unResultado.getString("telefono"));
            System.out.println("Mail: " + unResultado.getString("mail"));
            System.out.println("Genero: " + unResultado.getString("genero"));
            System.out.println("-------------------------------------------");
        }
        
        // cierro la conexion
        unaConexion.close();
    }
    
    
    public static void consultarUno(String nombre) throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        //creo una conexion
        Connection unaConexion = Conexion.obtenerConexion();
        
        //armo la query
        String unaConsulta = "select * from pasajeros where nombre = '" + nombre + "'";

        
        //creo una sentencia que ejecutara la query
        Statement unaSentencia = unaConexion.createStatement();
        
        //ejecuto la query y guardo el resultado
        ResultSet unResultado = unaSentencia.executeQuery(unaConsulta);
        
        // recorro el resultado y muetro en Consola
        while (unResultado.next()) {
            System.out.println("Nombre: " + unResultado.getString("nombre"));
            System.out.println("Apellido: " + unResultado.getString("apellido"));
            System.out.println("Fecha de nacimiento: " + unResultado.getString("fechaNacimiento"));
            System.out.println("Numero de pasaporte: " + unResultado.getString("pasaporte"));
            System.out.println("Telefono " + unResultado.getString("telefono"));
            System.out.println("Mail: " + unResultado.getString("mail"));
            System.out.println("Genero: " + unResultado.getString("genero"));
            System.out.println("-------------------------------------------");
        }
        
        // cierro la conexion
        unaConexion.close();
        
    }
    
     public static void insertar(Pasajero p) throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        //creo una conexion
        Connection unaConexion = Conexion.obtenerConexion();
        
        //armo la sentencia
        String unaInsercion = "insert into pasajeros(nombre, apellido, fechaNacimiento,pasaporte, telefono, mail, genero ) values(?, ?, ?, ?, ?, ?, ?)";
        
        //creo una sentencia que ejecutara la insercion
        PreparedStatement unaSentencia = unaConexion.prepareStatement(unaInsercion);
        
        //configuro los parametros de la sentencia
        unaSentencia.setString(1, p.getNombre());
        unaSentencia.setString(2, p.getApellido());
        unaSentencia.setDate(3, (java.sql.Date) p.getFechaNacimiento());
        unaSentencia.setString(4, p.getPasaporte());
        unaSentencia.setInt(5, p.getTelefono());
        unaSentencia.setString(6, p.getMail());
        unaSentencia.setString(7, p.getGenero());
        
        //ejecuto la sentencia
        unaSentencia.execute();
        
        System.out.println("Insercion correcta");
        
        //cierro la conexion
        unaConexion.close();
        
    }
     
     public static void eliminar(String apellido) throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        //creo una conexion
        Connection unaConexion = Conexion.obtenerConexion();
        
        //armo la sentencia
        String unaEliminacion = "delete from pasajeros where apellido = ?";
        
        //creo una sentencia que ejecutara la eliminacion
        PreparedStatement unaSentencia = unaConexion.prepareStatement(unaEliminacion);
        
        //configuro los parametros de la sentencia
        unaSentencia.setString(1, apellido);
        
        //ejecuto la sentencia
        unaSentencia.execute();
        
        System.out.println("Eliminacion correcta");
        
        //cierro la conexion
        unaConexion.close();
        
    }
     
     public static void actualizar(String nombreAnterior, String nombreNuevo) throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        //creo una conexion
        Connection unaConexion = Conexion.obtenerConexion();
        
        //armo la sentencia
        String unaActualizacion = "update pasajeros set nombre = ? where nombre = ?";
        
        //creo una sentencia que ejecutara la actualizacion
        PreparedStatement unaSentencia = unaConexion.prepareStatement(unaActualizacion);
        
        //configuro los parametros de la sentencia
        unaSentencia.setString(1, nombreNuevo);
        unaSentencia.setString(2, nombreAnterior);
        
        //ejecuto la sentencia
        unaSentencia.execute();
        
        System.out.println("Actualizacion correcta");
        
        //cierro la conexion
        unaConexion.close();
        
    }
    

}
