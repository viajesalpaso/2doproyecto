

package viajes;

import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;


public class Test {
    public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException, ParseException {
//        System.out.println("Consultar Todo: ");
//        Pasajero.consultarTodos();

//        System.out.println("Consultar Uno");
//        Pasajero.consultarUno("Carlos");
//        System.out.println("Insercion");
//          Scanner lector = new Scanner(System.in);
//              
//          System.out.println("Ingrese nombre: ");
//          String nombre = lector.next();
//          System.out.println("Ingrese apellido: ");
//          String apellido = lector.next();
//          System.out.println("Ingrese fecha de nacimiento");
//          String fechaStr = lector.next();
//          SimpleDateFormat dateFormat = new SimpleDateFormat("YYYY/MM/DD");
//          Date fecha = dateFormat.parse(fechaStr);
//          System.out.println("Ingrese numero de pasaporte: ");
//          String pasaporte = lector.next();
//          System.out.println("Ingrese telefono: ");
//          int telefono = lector.nextInt();
//          System.out.println("Ingrese mail: ");
//          String mail = lector.next();
//          System.out.println("genero: ");
//          String genero = lector.next();
//          
//          //armo el objeto con los datos introducidos x teclado
//          Pasajero p = new Pasajero(0, nombre, apellido, fecha, pasaporte, telefono, mail, genero);
//          
//          Pasajero.insertar(p);
//          Pasajero.consultarTodos();
//
//
           
//           System.out.println("Eliminacion");
//
//           Scanner lector = new Scanner(System.in);
//
//           System.out.println("Ingrese el apellido del pasajero a eliminar: ");
//           String apellido = lector.next();
//
//          //Invoco el metodo eliminar pasandole como parametro
//          //el nombre del alumno a eliminar
//          Pasajero.eliminar(apellido);
//         //verifico la eliminacion
//          Pasajero.consultarTodos();


        System.out.println("Actualizacion");

        Scanner lector = new Scanner(System.in);

        System.out.println("Ingrese el anterior nombre del alumno: ");
        String nombreAnterior = lector.next();
        
        System.out.println("Ingrese el nuevo nombre del alumno: ");
        String nombreNuevo = lector.next();

        //Invoco el metodo actualizar pasandole como parametros
        //el anterior y el nuevo nombre del alumno
        Pasajero.actualizar(nombreAnterior, nombreNuevo);

        //verifico la actualizacion
        Pasajero.consultarTodos();
    }

}
