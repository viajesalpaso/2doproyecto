

package viajes;


public class Reserva {
    
    private int idVuelo;
    

    public int getIdVuelo() {
        return idVuelo;
    }

    public void setIdVuelo(int idVuelo) {
        this.idVuelo = idVuelo;
    }


}
