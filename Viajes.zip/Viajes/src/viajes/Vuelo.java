

package viajes;


import com.mysql.cj.jdbc.PreparedStatementWrapper;
//import com.sun.jdi.connect.spi.Connection;
import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.Connection;



public class Vuelo {
    
    //atributos
    private int idVuelo;
    private String vuelo;
    private String origen;
    private String destino;
    private Date fechaSalida;
    private Time horaSalida;
    private int asientos;

    
    //Constructores
    public Vuelo() {
    }

    public Vuelo(int idVuelo ,String vuelo, String origen, String destino, Date fechaSalida, Time horaSalida, int asientos) {
        this.setIdVuelo(idVuelo);
        this.setVuelo(vuelo);
        this.setOrigen(origen);
        this.setDestino(destino);
        this.setFechaSalida(fechaSalida);
        this.setHoraSalida(horaSalida);
        this.setAsientos(asientos);
    }

    
    //getters and setters
    public int getIdVuelo() {
        return idVuelo;
    }

    public void setIdVuelo(int idVuelo) {
        this.idVuelo = idVuelo;
    }

    public String getVuelo() {
        return vuelo;
    }

    public void setVuelo(String vuelo) {
        this.vuelo = vuelo;
    }

    public String getOrigen() {
        return origen;
    }

    public void setOrigen(String origen) {
        this.origen = origen;
    }

    public String getDestino() {
        return destino;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }

    public Date getFechaSalida() {
        return fechaSalida;
    }

    public void setFechaSalida(Date fechaSalida) {
        this.fechaSalida = fechaSalida;
    }

    public Time getHoraSalida() {
        return horaSalida;
    }

    public void setHoraSalida(Time horaSalida) {
        this.horaSalida = horaSalida;
    }

    public int getAsientos() {
        return asientos;
    }

    public void setAsientos(int asientos) {
        this.asientos = asientos;
    }

    // Metodos
    @Override
    public String toString() {
        return  idVuelo +
                ", vuelo='" + vuelo + " - " +
                ", origen='" + origen + " - " +
                ", destino='" + destino + " - " +
                ", fechaSalida=" + fechaSalida + 
                ", horaSalida=" + horaSalida +
                ", asientos=" + asientos;
    }
    
    // metodos de acceso a datos ABMC (CRUD)
     public static void consultarTodos() throws ClassNotFoundException, SQLException, InstantiationException, IllegalAccessException, IOException {
        Connection unaConexion = (Connection) Conexion.obtenerConexion();
        String unaConsulta = "SELECT * FROM vuelos";
        Statement unaSentencia = unaConexion.createStatement();
        ResultSet unResultado = unaSentencia.executeQuery(unaConsulta);

        while (unResultado.next()) {
            // Leer los datos de la base de datos y mostrarlos o almacenarlos como sea necesario.
            
            String vuelo = unResultado.getString("vuelo");
            System.out.println("Número de vuelo: " + vuelo);
            System.out.println("Origen: " + unResultado.getString("origen"));
            System.out.println("Destino: " + unResultado.getString("destino"));
            System.out.println("Fecha de Salida: " + unResultado.getString("fechaSalida"));
            System.out.println("Hora de Salida: " + unResultado.getString("horaSalida"));
            System.out.println("Cantidad de Asientos: " + unResultado.getString("asientos"));
            System.out.println("-------------------------------------------");
        }

        unaConexion.close();
    }

    public void insertar() throws ClassNotFoundException, SQLException, InstantiationException, IllegalAccessException, IOException {
        Connection unaConexion = (Connection) Conexion.obtenerConexion();
        String unaInsercion = "INSERT INTO vuelos (vuelo, origen, destino, fechaSalida, horaSalida, asientos) VALUES (?, ?, ?, ?, ?, ?)";
        PreparedStatement unaSentencia = unaConexion.prepareStatement(unaInsercion);
        unaSentencia.setString(1, this.getVuelo());
        unaSentencia.setString(2, this.getOrigen());
        unaSentencia.setString(3, this.getDestino());
        unaSentencia.setDate(4, this.getFechaSalida());
        unaSentencia.setTime(5, this.getHoraSalida());
        unaSentencia.setInt(6, this.getAsientos());
        unaSentencia.execute();
        System.out.println("Inserción correcta");
        unaConexion.close();
    }

    public static void eliminar(int idVuelo) throws ClassNotFoundException, SQLException, InstantiationException, IllegalAccessException, IOException {
        Connection unaConexion = (Connection) Conexion.obtenerConexion();
        String unaEliminacion = "DELETE FROM vuelos WHERE idVuelo = ?";
        PreparedStatement unaSentencia = unaConexion.prepareStatement(unaEliminacion);
        unaSentencia.setInt(1, idVuelo);
        unaSentencia.execute();
        System.out.println("Eliminación correcta");
        unaConexion.close();
    }

    public void actualizar() throws ClassNotFoundException, SQLException, InstantiationException, IllegalAccessException, IOException {
        Connection unaConexion = (Connection) Conexion.obtenerConexion();
        String unaActualizacion = "UPDATE vuelos SET vuelo = ?, origen = ?, destino = ?, fechaSalida = ?, horaSalida = ?, asientos = ? WHERE idVuelo = ?";
        PreparedStatement unaSentencia = unaConexion.prepareStatement(unaActualizacion);
        unaSentencia.setString(1, this.getVuelo());
        unaSentencia.setString(2, this.getOrigen());
        unaSentencia.setString(3, this.getDestino());
        unaSentencia.setDate(4, this.getFechaSalida());
        unaSentencia.setTime(5, this.getHoraSalida());
        unaSentencia.setInt(6, this.getAsientos());
        unaSentencia.setInt(7, this.getIdVuelo());
        unaSentencia.execute();
        System.out.println("Actualización correcta");
        unaConexion.close();
    }
}

