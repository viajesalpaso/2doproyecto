

package viajes;


import com.sun.jdi.connect.spi.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Time;


public class Vuelo {
    
    //atributos
    private int idVuelo;
    private String vuelo;
    private String origen;
    private String destino;
    private Date fechaSalida;
    private Time horaSalida;
    private int asientos;

    
    //Constructores
    public Vuelo() {
    }

    public Vuelo(String vuelo, String origen, String destino, Date fechaSalida, Time horaSalida, int asientos) {
        this.setVuelo(vuelo);
        this.setOrigen(origen);
        this.setDestino(destino);
        this.setFechaSalida(fechaSalida);
        this.setHoraSalida(horaSalida);
        this.setAsientos(asientos);
    }

    
    //getters and setters
    public int getIdVuelo() {
        return idVuelo;
    }

    public void setIdVuelo(int idVuelo) {
        this.idVuelo = idVuelo;
    }

    public String getVuelo() {
        return vuelo;
    }

    public void setVuelo(String vuelo) {
        this.vuelo = vuelo;
    }

    public String getOrigen() {
        return origen;
    }

    public void setOrigen(String origen) {
        this.origen = origen;
    }

    public String getDestino() {
        return destino;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }

    public Date getFechaSalida() {
        return fechaSalida;
    }

    public void setFechaSalida(Date fechaSalida) {
        this.fechaSalida = fechaSalida;
    }

    public Time getHoraSalida() {
        return horaSalida;
    }

    public void setHoraSalida(Time horaSalida) {
        this.horaSalida = horaSalida;
    }

    public int getAsientos() {
        return asientos;
    }

    public void setAsientos(int asientos) {
        this.asientos = asientos;
    }

    // Metodos
    @Override
    public String toString() {
        return  idVuelo +
                ", vuelo='" + vuelo + " - " +
                ", origen='" + origen + " - " +
                ", destino='" + destino + " - " +
                ", fechaSalida=" + fechaSalida + 
                ", horaSalida=" + horaSalida +
                ", asientos=" + asientos;
    }
    
    // metodos de acceso a datos ABMC (CRUD)
     public static void consultarTodos() throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException{
        // creo una conexion
         Connection unaConexion = (Connection) Conexion.obtenerConexion();
        
        // armo la query
        String unaConsulta = "select * from vuelos";
        
        
        // creo una sentencia que ejecute la query 
        
        
        
        // Ejecuto la query y guardo el resultado
        
        
        // recorro el resultado y muetro en Consola
        
        
        // cierro la conexion
        
    }
}

