package viajes;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;

public class Vuelo {

    private int idVuelo;
    private String vuelo;
    private String origen;
    private String destino;
    private Date fechaSalida;
    private Time horaSalida;
    private int asientos;

    public Vuelo() {
    }

    public Vuelo(int idVuelo, String vuelo, String origen, String destino, Date fechaSalida, Time horaSalida, int asientos) {
        this.setIdVuelo(idVuelo);
        this.setVuelo(vuelo);
        this.setOrigen(origen);
        this.setDestino(destino);
        this.setFechaSalida(fechaSalida);
        this.setHoraSalida(horaSalida);
        this.setAsientos(asientos);
    }

    public int getIdVuelo() {
        return idVuelo;
    }

    public void setIdVuelo(int idVuelo) {
        this.idVuelo = idVuelo;
    }

    public String getVuelo() {
        return vuelo;
    }

    public void setVuelo(String vuelo) {
        this.vuelo = vuelo;
    }

    public String getOrigen() {
        return origen;
    }

    public void setOrigen(String origen) {
        this.origen = origen;
    }

    public String getDestino() {
        return destino;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }

    public Date getFechaSalida() {
        return fechaSalida;
    }

    public void setFechaSalida(Date fechaSalida) {
        this.fechaSalida = fechaSalida;
    }

    public Time getHoraSalida() {
        return horaSalida;
    }

    public void setHoraSalida(Time horaSalida) {
        this.horaSalida = horaSalida;
    }

    public int getAsientos() {
        return asientos;
    }

    public void setAsientos(int asientos) {
        this.asientos = asientos;
    }

    @Override
    public String toString() {
        return idVuelo +
                ", vuelo='" + vuelo + " - " +
                ", origen='" + origen + " - " +
                ", destino='" + destino + " - " +
                ", fechaSalida=" + fechaSalida +
                ", horaSalida=" + horaSalida +
                ", asientos=" + asientos;
    }

    public static void consultarTodos() throws ClassNotFoundException, SQLException, InstantiationException, IllegalAccessException, IOException {
        Connection unaConexion = Conexion.obtenerConexion();
        String unaConsulta = "SELECT * FROM vuelos";
        PreparedStatement unaSentencia = unaConexion.prepareStatement(unaConsulta);
        ResultSet unResultado = unaSentencia.executeQuery();

        while (unResultado.next()) {
            String vuelo = unResultado.getString("vuelo");
            System.out.println("Número de vuelo: " + vuelo);
            System.out.println("Origen: " + unResultado.getString("origen"));
            System.out.println("Destino: " + unResultado.getString("destino"));
            System.out.println("Fecha de Salida: " + unResultado.getString("fechaSalida"));
            System.out.println("Hora de Salida: " + unResultado.getString("horaSalida"));
            System.out.println("Cantidad de Asientos: " + unResultado.getString("asientos"));
            System.out.println("-------------------------------------------");
        }

        unaConexion.close();
    }
}

